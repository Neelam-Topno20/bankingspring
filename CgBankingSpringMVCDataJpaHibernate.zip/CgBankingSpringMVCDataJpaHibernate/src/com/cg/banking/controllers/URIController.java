package com.cg.banking.controllers;
import java.util.ArrayList;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import com.cg.banking.beans.Account;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
@Controller
public class URIController {
	Customer customer;
	Account account;
	Transaction transaction;
	ArrayList<Customer> customerList;
	@RequestMapping(value= {"/","/home","/indexPage"})
	public String getIndexPage() {
		return "indexPage";
	}
	@RequestMapping("/register")
	public String getRegisterPage() {
		return "registerPage";
	}
	@RequestMapping("/login")
	public String getLoginPage() {
		return "loginPage";
	}
	@RequestMapping("/depositAmount")
	public String getDepositAmountPage() {
		return "depositAmountPage";
	}
	@RequestMapping("/withdrawAmount")
	public String getWithdrawAmountPage() {
		return "withdrawAmountPage";
	}
	@ModelAttribute
	public Customer getCustomer() {
		customer=new Customer();
		return customer;
	}
	@ModelAttribute
	public ArrayList<Customer> getCustomerList() {
		customerList=new ArrayList<Customer>();
		return customerList;
	}
	@RequestMapping("/fundTransfer")
	public String getAssociateIdPage() {
		return "getfundTransferDetailsPage";
	}
	@RequestMapping("/getAssociateDetails")
	public String AssociateDetails() {
		return "associateIdPageAssociateDetails";
	}
}