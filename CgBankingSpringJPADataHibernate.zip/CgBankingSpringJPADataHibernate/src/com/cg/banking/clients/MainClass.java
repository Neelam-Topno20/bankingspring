package com.cg.banking.clients;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import com.cg.banking.beans.Customer;
import com.cg.banking.beans.Transaction;
import com.cg.banking.exceptions.AccountBlockedException;
import com.cg.banking.exceptions.AccountNotFoundException;
import com.cg.banking.exceptions.BankingServicesDownException;
import com.cg.banking.exceptions.InsufficientAmountException;
import com.cg.banking.exceptions.InvalidAccountTypeException;
import com.cg.banking.exceptions.InvalidAmountException;
import com.cg.banking.exceptions.InvalidPinNumberException;
import com.cg.banking.services.BankingService;
public class MainClass {
	@SuppressWarnings("resource")
	public static void main(String[] args) throws InvalidAmountException, InvalidAccountTypeException, BankingServicesDownException, AccountNotFoundException, AccountBlockedException, InsufficientAmountException, InvalidPinNumberException {
		ApplicationContext context=new ClassPathXmlApplicationContext("projectbeans.xml");
		BankingService bankingService=(BankingService) context.getBean("bankingService");
		
		 Customer customer=bankingService.openAccount("NEELAM","ashav2101@gmail.com","Pune","HHTPK0434B","Saving",1200,"Cricket");
		 System.out.println(customer.getCustomerId());
		 Customer customer2=bankingService.openAccount("NEELAM","ashav2101@gmail.com","Pune","HHTPK0434B","Saving",1200,"Cricket");

		 Customer customer3= bankingService.getCustomerDetails(customer.getCustomerId());	
		 System.out.println(customer2.toString());
		System.out.println(bankingService.fundTransfer(52, 53, 100));
		 List<Transaction> transactions=bankingService.getAccountAllTransaction(52);
		 for(Transaction transaction:transactions)
			 System.out.println(transaction.toString());
			 //bankingService.withdrawAmount(account.getAccountNo(), 200);
		 //System.out.println(bankingService.getCustomerDetails(302));
		//System.out.println(accString);
	}
}
